FRAMEWORK UTILISES : Bootstrap
Nous avons rencotré plusieurs difficultés telles que ; utiliser bootstrap pour la premiere fois, gerer les icones 
Le site existant est simple pas assez de design

Historique de LARRY WALL
 Larry Wall est né le 27/09/1954 à Los Angeles aux Etats-Unis il obtient son Bachelor en 1976 à la Seattle Pacific university. Il poursuit ses études à l’université de Berkeley où, avec sa femme, il étudie la linguistique.
Wall explique qu’à l’époque, sa femme et lui souhaitaient créer un système de transcription d’une langue africaine non écrite, mais des raisons de santé ont changé leur plan. Finalement, à la fin de ses études, Wall est recruté au jet propulsion laboratory.
La formation de linguistique de Wall, ainsi que sa foi chrétienne, ont beaucoup influencé Perl : Wall motive souvent les choix fait pour Perl à partir des langues naturelles ; le no, de Perl est une référence discrète à un passage de la bible ; la création d’objet en Perl se fait avec un mot clef « bless » que l’on peut traduire par « bénir ».
Si le langage Perl est la raison de sa célébrité, on doit également à Larry Wall d’autre logiciels :  Rn (Read news) de consultation d’informations ;
 Patch, l’outil de mise à jour globale d’un code source.
Il a gagné IOCCC à deux reprises et a reçu en 1998 le prix pour le développement du logiciel libre de la Free Software Foundation.il travaille actuellement à la spécification de perl6, refonte majeure du langage. Au-delà de son habile » technique, Larry est connu pour l’humour qui transparait dans son connu pour l’humour qui transparait dans son code source, dans ses publication, et qu’il utilise parfois sur Usenet.
Créateur du programming perl (souvent appelé le Camel Book)-référence pour le programmeur perl- il a aussi coédité des livres qu’il a écrits ou coécrits sont publiés par O’Reilly.
Un canular fut lancé en 2000 sur l’internet selon lequel « la contribution à l’économie numérique avait décidé le maire de New York à lui dédier une rue de son vivant ».il s’agissait bien entendu d’une référence malicieuse à Wall Street. Larry Wall reçut néanmoins des actions gratuites d’Amazon à titre de remerciement pour la contribution de son langage à mettre en place le service dans de très courts délais.
Larry Wall, avec RANDAL L. SCHWARTZ et Tom Christiansen, dans la seconde édition de programming perl, a explicité les trois vertus du programmeur :
« Les trois principales qualité du programmeur sont la paresse, L’impatience et l’orgueil » (Camel book)
1. PARESSE : la qualité qui vous pousse à faire de grands efforts pour réduire le total des dépenses d’énergie. C’est elle qui vous fait écrire des programme qui gagner du temps sans effort et que d’autre trouveront utiles, et c’est elle qui vous pousse à documenter ce que vous avez fait pour ne pas avoir à répondre à plein de question.
2. IPATIENCE : L’énervement que vous ressentez lorsque l’ordinateur est paresseux. l’impatience vous pousse à écrire de programmes qui ne répondent pas seulement à vos besoins, mais qui les anticipent même. ou du moins qui font comme si.
3. ORGUEIL : c’est la qualité qui vous fait écrire et maintenir des programmes desquels personne ne voudra dire du mal.

LISTE
ELLE S'affiche également en cliquant le bouton liste en bas de la page d'acceuil

MAKENE BALUME Aaron    M 20MB283 
KASONGO KALALA Franck   M 20KK184 
MUZANGU NGOY Loic   M 20MN415 
KYUNGU BANZE Steve   M 19KB246 
KAYA KAHILA Yves    M 20KK211 
MUMBERE MWANGAZA David  M 20MM381 
MALOBA NUMBI Tracy   F 19MN271  
RUKAN DISASH Francis   M 20RD506 
TSHILOMBO NTUMBA Davina  M 20TN539 
SAKOKO MOTA Ken    M 19SM472